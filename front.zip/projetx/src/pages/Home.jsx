import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import '../styles/Home.css';
import '../styles/SearchBar.css';
import '../styles/SearchResults.css';
import SearchBar from '../components/SearchBar';
import SmartDeviceCard from '../components/SmartDeviceCard';
import { mockData } from '../data/mockData';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';


function Home() {
  const [searchResults, setSearchResults] = useState([]);
  // const [allObjects, setAllObjects] = useState([]);
  //const [userRole, setUserRole] = useState(''); // Exemple de rôle utilisateur : 'visiteur', 'utilisateur', 'admin'


  const [isLoggedIn, setIsLoggedIn] = useState(false);
  //const [userEmail, setUserEmail] = useState('');
  const [userNom, setUserNom] = useState('');
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);

  const location = useLocation();
  const { selectedDevices } = location.state || {};  // Récupérer les appareils sélectionnés depuis la navigation

  // Si rien n'est passé via state, récupérer depuis localStorage
  const storedSelectedDevices = JSON.parse(localStorage.getItem('selectedDevices')) || [];
  const devicesToShow = selectedDevices?.length ? selectedDevices : storedSelectedDevices;

  // Filtrer les appareils sélectionnés à partir des mockData
  const selectedItems = mockData.connectedDevices.filter(device => devicesToShow.includes(device.id));



  // Vérifier l'état de la session au démarrage
  useEffect(() => {
    fetch('http://localhost:8000/checkSession.php', {
      method: 'GET',
      credentials: 'include', // inclure les cookies pour vérifier la session
    })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          setIsLoggedIn(true);
          //setUserEmail(data.email); 
          setUserNom(data.nom);
        }
      })
      .catch(error => {
        console.error('Erreur lors de la vérification de la session:', error);
      });
  }, []);

  // Fonction de déconnexion
  const handleLogout = () => {
    fetch('http://localhost:8000/logout.php', {
      method: 'GET',
      credentials: 'include', // inclure les cookies pour gérer la session
    })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          setIsLoggedIn(false);
          //setUserEmail('');
          setUserNom('');
          navigate('/'); // Rediriger vers la page d'accueil après déconnexion
        } else {
          console.error('Erreur de déconnexion:', data.message);
        }
      })
      .catch(error => {
        console.error('Erreur réseau:', error);
      });
  };

  useEffect(() => {
    fetchUsers();
  }, []);
  const fetchUsers = () => {
    const adminEmail = 'admin@example.com';  // L'email de l'admin

    console.log(" Envoi de l'email admin :", adminEmail);  // Affiche l'email envoyé

    const data = new URLSearchParams();
    data.append('admin_email', adminEmail);  // Ajoute l'email dans les données envoyées

    fetch("http://localhost:8000/GetUsers.php", {
      method: "POST",  // Méthode POST pour envoyer les données
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"  // Formulaire x-www-form-urlencoded
      },
      body: data  // Envoi des données avec l'email de l'admin
    })
      .then(response => response.json())  // Traite la réponse comme un JSON
      .then(data => {
        console.log(" Réponse brute du serveur:", data);

        if (data.users) {
          setUsers(data.users);  // Mets à jour la liste des utilisateurs
        } else {
          console.error(" Erreur : Pas de données valides dans la réponse");
        }
      })
  };




  // Exemple d'objet connecté dynamique
  const [demoDevice, setDemoDevice] = useState({
    name: "Thermostat Salon",
    currentTemp: 21.0,
    targetTemp: 23.0,
    mode: "Automatique",
    connectivity: "Wi-Fi (signal fort)",
    battery: 80,
    lastSeen: "Aujourd'hui à 10:00",
    status: "Connecté"
  });

  const handleSearch = (searchParams) => {
    const { term, type, filter, brand, status } = searchParams;
    let results = [];

    Object.values(mockData).forEach(typeData => {
      const filtered = typeData.filter(item => {
        const matchesTerm = !term || item.name.toLowerCase().includes(term.toLowerCase()) || item.description.toLowerCase().includes(term.toLowerCase());
        const matchesType = !type || item.type === type;
        const matchesFilter = !filter || item.category === filter;
        const matchesBrand = !brand || item.brand?.toLowerCase() === brand.toLowerCase();
        const matchesStatus = !status || item.status?.toLowerCase() === status.toLowerCase();
        return matchesTerm && matchesType && matchesFilter && matchesBrand && matchesStatus;
      });
      results.push(...filtered);
    });

    setSearchResults(results);
  };

  // Fonction de mise à jour de la température cible ou actuelle
  const updateTemperature = (newTemp) => {
    setDemoDevice(prevState => ({
      ...prevState,
      targetTemp: newTemp,  // Mettre à jour la température cible
    }));
  };

  const goToMessagePage = () => {
    navigate('/message');
  };



  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Bienvenue sur la plateforme intelligente</h1>
        <p>Explorez les objets connectés et services disponibles.</p>
        <SearchBar onSearch={handleSearch} filters={['type', 'category', 'brand', 'status']} />
        <div className="home-buttons">
          {isLoggedIn ? (
            <div>
              <h2>Bienvenue,{userNom}!</h2>
              <button onClick={handleLogout}>Se déconnecter</button>
              <Link to="/login" className="btn btn-login">Profil</Link>
            </div>
          ) : (
            <div>
              <Link to="/signup" className="btn btn-signup">S'inscrire</Link>
              <Link to="/login" className="btn btn-login">Se connecter</Link>
            </div>
          )}
        </div>
      </header>

      <main className="home-main">
        {searchResults.length > 0 && (
          <div className="search-results">
            <h3>Résultats de la recherche</h3>
            <div className="results-grid">
              {searchResults.map(item => (
                <div key={item.id} className="result-card small-card">
                  <h4>{item.name}</h4>
                  <p><strong>{item.type}</strong></p>
                  <p className="status">{item.status}</p>
                </div>
              ))}
            </div>
          </div>
        )}
        {isLoggedIn && (
          <section className="utilisateurs-section">
            <div>
              <h3>Liste des utilisateurs</h3>
              <table border="1">
                <thead>
                  <tr>
                    <th>Nom</th>
                    <th>Rôle</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user, index) => (
                    <tr key={index}>
                      <td>{user.nom}</td>
                      <td>{user.role}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

       







        {isLoggedIn && (
          <section className="live-device">
            <h3>Appareil connecté en direct</h3>
            {selectedItems.length > 0 ? (
              <ul>
                {selectedItems.map((device) => (
                  <li key={device.id}>
                    <h3>{device.name} ({device.type})</h3>
                    <p>Status: {device.status || 'N/A'}</p>
                    <p>Connectivity: {device.connectivity}</p>
                    <p>Battery Status: {device.batteryStatus}%</p>
                    <p>Last Interaction: {device.lastInteraction}</p>
                    {device.image && <img src={device.image} alt={device.name} style={{ width: '150px', height: '150px' }} />}
                  </li>
                ))}
              </ul>
            ) : (
              <p>Aucun appareil sélectionné.</p>
            )}
          </section>
        )}
      </main>
      <button onClick={goToMessagePage}>
        Envoyer un message à l'admin
      </button>
      <footer className="home-footer">
        <p>© 2025 Ville intelligente – Plateforme utilisateur</p>
      </footer>
    </div>
  );
}

export default Home;





/*
  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Bienvenue sur la plateforme intelligente</h1>
        <p>Explorez les objets connectés et services disponibles.</p>
        <SearchBar onSearch={handleSearch} filters={['type', 'category', 'brand', 'status']} />
        <div className="home-buttons">
        {isLoggedIn ? (
        <div>
          <h2>Bienvenue, {userEmail}!</h2>
          <button onClick={handleLogout}>Se déconnecter</button>
        </div>
        

      ) : (
        <div>
          <Link to="/signup" className="btn btn-signup">S'inscrire</Link>
          <Link to="/login" className="btn btn-login">Se connecter</Link>
          </div>
      )}
        </div>
      </header>

      <main className="home-main">
        {searchResults.length > 0 && (
          <div className="search-results">
            <h3>Résultats de la recherche</h3>
            <div className="results-grid">
              {searchResults.map(item => (
                <div key={item.id} className="result-card small-card">
                  <h4>{item.name}</h4>
                  <p><strong>{item.type}</strong></p>
                  <p className="status">{item.status}</p>
                </div>
              ))}
            </div>
          </div>
        )}
    
        <section className="objects-section">
          <h2>Objets connectés à découvrir</h2>
          <div className="results-grid">
            {allObjects.slice(0, 6).map(item => (
              <div
              key={item.id}
              className="result-card"
              style={{ backgroundImage: `url(${item.image})` }}
              >
              <h4>{item.name}</h4>
              <p><strong>{item.type}</strong></p>echo json_encode(["success" => true, "email" => $_SESSION['email']]);
              <p className="status">{item.status}</p>
            </div>
            ))}
          </div>
        </section>
    
        
        <section className="live-device">
          <h3>Appareil connecté en direct</h3>
          <SmartDeviceCard device={demoDevice} />
          
          
        </section>
      </main>

      <footer className="home-footer">
        <p>© 2025 Ville intelligente – Plateforme utilisateur</p>
      </footer>
    </div>
  );
}

<section className="objects-section">
          <h2>Objets connectés à découvrir</h2>
          <div className="results-grid">
            {allObjects.slice(0, 6).map(item => (
              <div
                className="result-card"
                style={{ backgroundImage: `url(${item.image})` }}
              >
                <h4>{item.name}</h4>
                <p><strong>{item.type}</strong></p>
                <p className="status">{item.status}</p>
              </div>

            ))}
          </div>
          <div
            className="result-card"
            style={{ backgroundImage: `url('/styles/img/lock.jpg')` }}
          >
            <h4>Test</h4>
          </div>

        </section>





*/


