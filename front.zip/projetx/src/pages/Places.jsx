import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Home.css';

function Places() {
  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Lieux incontournables</h1>
      </header>
      
      <main className="home-main">
        <div className="home-content">
          <h2>Découvrez les lieux emblématiques de notre ville</h2>
          <p>Explorez les sites historiques, culturels et naturels qui font la renommée de notre ville.</p>
          
          {/* Liste des lieux à ajouter ici */}
          <div className="places-list">
            <div className="place-card">
              <h3>Cathédrale historique</h3>
              <p>Construite au XIIe siècle, cette cathédrale est un chef-d'œuvre de l'architecture gothique.</p>
              <p>Adresse: Place de la Cathédrale</p>
            </div>
            
            <div className="place-card">
              <h3>Parc municipal</h3>
              <p>Un espace vert de 5 hectares au cœur de la ville, idéal pour les promenades et les pique-niques.</p>
              <p>Adresse: Avenue des Tilleuls</p>
            </div>
            
            <div className="place-card">
              <h3>Musée d'art moderne</h3>
              <p>Une collection impressionnante d'œuvres d'art du XXe siècle dans un bâtiment contemporain.</p>
              <p>Adresse: Rue des Beaux-Arts</p>
            </div>
          </div>
        </div>
        
        <div className="home-buttons">
          <Link to="/" className="btn btn-primary">Retour à l'accueil</Link>
        </div>
      </main>
      
      <footer className="home-footer">
        <p>© 2023 Ville de "Nom de la ville" - Tous droits réservés</p>
      </footer>
    </div>
  );
}

export default Places;