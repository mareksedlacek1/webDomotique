import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Home.css';

function Transport() {
  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Se déplacer à "nom ville"</h1>
      </header>
      
      <main className="home-main">
        <div className="home-content">
          <h2>Options de transport pour "nom ville"</h2>
          <p>Découvrez les différentes façons de vous rendre à "nom ville" et de vous déplacer dans la région.</p>
          
          <div className="transport-options">
            <div className="transport-card">
              <h3>Transports en commun</h3>
              <p>Bus: Ligne 68 depuis Genève, arrêt "nom ville"-Centre"</p>
              <p>Horaires: 6h-22h, toutes les 30 minutes</p>
            </div>
            
            <div className="transport-card">
              <h3>En voiture</h3>
              <p>Depuis Genève: 25 minutes via la D984</p>
              <p>Depuis Lyon: 1h45 via l'A42</p>
              <p>Parking gratuit disponible au centre-ville</p>
            </div>
            
            <div className="transport-card">
              <h3>Vélo et mobilité douce</h3>
              <p>Pistes cyclables reliant "nom ville" aux communes voisines</p>
              <p>Location de vélos électriques au point d'information touristique</p>
            </div>
            
            <div className="transport-card">
              <h3>Taxis et VTC</h3>
              <p>Plusieurs compagnies de taxis desservent la région</p>
              <p>Applications de VTC disponibles depuis les grandes villes</p>
            </div>
          </div>
        </div>
        
        <div className="home-buttons">
          <Link to="/" className="btn btn-primary">Retour à l'accueil</Link>
        </div>
      </main>
      
      <footer className="home-footer">
        <p>Pour plus d'informations, contactez l'office de tourisme au 04.XX.XX.XX.XX</p>
      </footer>
    </div>
  );
}

export default Transport;