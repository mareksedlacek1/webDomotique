import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Home.css';

function Events() {
  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Événements à venir</h1>
      </header>
      
      <main className="home-main">
        <div className="home-content">
          <h2>Découvrez les prochains événements de notre ville</h2>
          <p>Retrouvez ici tous les événements culturels, sportifs et festifs à venir dans notre ville.</p>
          
          {/* Liste des événements à ajouter ici */}
          <div className="events-list">
            <div className="event-card">
              <h3>Festival de musique</h3>
              <p>Date: 15-17 juillet 2023</p>
              <p>Lieu: Place centrale</p>
            </div>
            
            <div className="event-card">
              <h3>Exposition d'art contemporain</h3>
              <p>Date: 5-20 août 2023</p>
              <p>Lieu: Musée municipal</p>
            </div>
            
            <div className="event-card">
              <h3>Marathon de la ville</h3>
              <p>Date: 10 septembre 2023</p>
              <p>Lieu: Centre-ville</p>
            </div>
          </div>
        </div>
        
        <div className="home-buttons">
          <Link to="/" className="btn btn-primary">Retour à l'accueil</Link>
        </div>
      </main>
      
      <footer className="home-footer">
        <p>© 2023 Ville de "Nom de la ville" - Tous droits réservés</p>
      </footer>
    </div>
  );
}

export default Events;