import React, { useState } from 'react';

function SearchBar({ onSearch }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchType, setSearchType] = useState(''); // '', 'places', 'events' ou 'information'
  const [filter, setFilter] = useState('all');

  const handleSearch = (e) => {
    e.preventDefault();
    onSearch({
      term: searchTerm,
      type: searchType,
      filter: filter
    });
  };

  return (
    <div className="search-container">
      <form onSubmit={handleSearch} className="search-form">
        <div className="search-inputs">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Rechercher..."
            className="search-input"
          />

          <select
            value={searchType}
            onChange={(e) => setSearchType(e.target.value)}
            className="search-select"
          >
            <option value="">Sélectionner une catégorie</option>
            <option value="places">Lieux</option>
            <option value="events">Événements</option>
            <option value="information">Information</option>
          </select>

          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="search-select"
          >
            {searchType === 'places' ? (
              <>
                <option value="all">Toutes les catégories</option>
                <option value="park">Parcs</option>
                <option value="museum">Musées</option>
                <option value="monument">Monuments</option>
              </>
            ) : searchType === 'events' ? (
              <>
                <option value="all">Toutes les périodes</option>
                <option value="today">Aujourd'hui</option>
                <option value="week">Cette semaine</option>
                <option value="month">Ce mois</option>
              </>
            ) : (
              <>
                <option value="all">Toutes les catégories</option>
                <option value="news">Actualités</option>
                <option value="services">Services municipaux</option>
                <option value="procedures">Démarches administratives</option>
              </>
            )}
          </select>

          <button type="submit" className="search-button">
            Rechercher
          </button>
        </div>
      </form>
    </div>
  );
}

export default SearchBar;