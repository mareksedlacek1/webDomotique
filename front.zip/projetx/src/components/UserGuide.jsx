import '../styles/UserGuide.css'; // Tu peux créer ce fichier pour ajouter du style

function UserGuide() {
  return (
    <section className="user-guide">
      <h2>Fonctionnalités accessibles aux utilisateurs simples</h2>

      <p>
        En plus de la gestion de leur profil, les utilisateurs <strong>inscrits sur la plateforme</strong> peuvent
        rechercher et consulter les <strong>objets connectés</strong> ainsi que les <strong>services intelligents</strong> proposés.
      </p>

      <p>
        Lors de la connexion, ils atterrissent directement sur une page de tableau de bord affichant les services disponibles,
        comme par exemple la <em>consommation d’énergie de la machine à laver</em> ou les <em alert="true">données d’un capteur</em>.
      </p>

      <h3>Moteur de recherche</h3>
      <p>
        La recherche se fait via un moteur intelligent, utilisant :
      </p>
      <ul>
        <li>🔍 <strong>Des mots-clés</strong> dans le nom ou la description (ex. <em>Thermostat Salon</em>, <em>température</em>)</li>
        <li>🏷️ <strong>La marque</strong> (ex. <em>Philips</em>)</li>
        <li>🧩 <strong>Le type</strong> (ex. <em>thermostat</em>, <em>caméra</em>, <em>capteur</em>)</li>
        <li>🔌 <strong>L’état</strong> de l’objet (ex. <em>Connecté</em>, <em>Inactif</em>)</li>
      </ul>

      <h3>Exemple d’objet connecté</h3>
      <div className="object-example">
        <p><strong>ID unique :</strong> Thermo123</p>
        <p><strong>Nom :</strong> Thermostat Salon</p>
        <p><strong>Température actuelle :</strong> 21°C</p>
        <p><strong>Température cible :</strong> 23°C</p>
        <p><strong>Mode :</strong> Automatique</p>
        <p><strong>Connectivité :</strong> Wi-Fi (signal fort)</p>
        <p><strong>État de batterie :</strong> 65%</p>
        <p><strong>Dernière interaction :</strong> Aujourd’hui à 10:00</p>
      </div>
    </section>
  );
}

export default UserGuide;