import React, { useState, useEffect } from 'react';
import '../styles/SmartDeviceCard.css'; // Assurez-vous que ce fichier contient les styles

function SmartDeviceCard({ device }) {
  const [currentTemp, setCurrentTemp] = useState(device.currentTemp);
  const [battery, setBattery] = useState(device.battery); // Initialisation avec la valeur de batterie du device passé en prop
  const [mode, setMode] = useState(device.mode); // Nouveau paramètre : mode d'alimentation
  const [temperatureStarted, setTemperatureStarted] = useState(false); // Variable pour contrôler le démarrage de la température

  // Fonction pour gérer la décharge ou la recharge de la batterie
  const updateBattery = (mode, battery) => {
    if (mode === 'batterie') {
      return battery > 0 ? battery - 0.1 : 0; // Décharge de la batterie
    } else if (mode === 'branché') {
      return battery < 100 ? battery + 0.1 : 100; // Recharge de la batterie
    }
    return battery; // Aucun changement si mode invalide
  };

  // Simulation dynamique : température qui change plus rapidement
  useEffect(() => {
    // Créer un délai de 5 secondes avant de commencer à changer la température
    const timeout = setTimeout(() => {
      setTemperatureStarted(true); // Permet de commencer la mise à jour de la température après 5 secondes
    }, 5000); // 5 secondes de délai avant de commencer

    const interval = setInterval(() => {
      if (temperatureStarted) {
        // Mise à jour de la température actuelle pour tendre plus rapidement vers la température cible
        setCurrentTemp(prev => {
          const diff = device.targetTemp - prev;
          const step = diff > 0 ? 0.2 : (diff < 0 ? -0.1 : 0); // Augmentation de la vitesse de convergence à 0.1
          return parseFloat((prev + step).toFixed(1)); // Arrondir à 1 décimale
        });
      }

      // Mise à jour de la batterie en fonction du mode
      setBattery(prev => {
        const newBattery = updateBattery(mode, prev);
        localStorage.setItem(`battery-${device.name}`, newBattery.toFixed(1)); // Sauvegarder la nouvelle valeur de la batterie dans localStorage
        return parseFloat(newBattery.toFixed(1)); // Assurez-vous que c'est un nombre
      });

    }, 1000); // Mettre à jour chaque seconde pour rendre la simulation plus réactive

    // Nettoyer les intervalles et timeout lorsque le composant est démonté
    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, [mode, device.targetTemp, temperatureStarted, device.name]); // Dépendance au mode d'alimentation, à la température cible et au nom du device

  return (
    <div className="smart-device-card">
      <h3>{device.name}</h3>
      <p><strong>Temp. actuelle :</strong> {currentTemp}°C</p>
      <p><strong>Temp. cible :</strong> {device.targetTemp}°C</p>
      <p><strong>Mode :</strong> {device.mode}</p>
      <p><strong>Connectivité :</strong> {device.connectivity}</p>
      <p><strong>Batterie :</strong> {battery}%</p>
      <p><strong>Dernière interaction :</strong> {device.lastSeen}</p>
      <p className={`status ${device.status.toLowerCase()}`}>
        <strong>État :</strong> {device.status}
      </p>
      
      <br />  
      <hr />
      
      {/* Bloc pour le contrôle de la température */}
      <div className="temperature-control">
        <label htmlFor="tempRange"  bolder>Réglage de la température</label>
        <input 
          id="tempRange"
          type="range" 
          min="10" 
          max="30" 
          step="0.5" 
          value={device.targetTemp}
          onChange={(e) => device.targetTemp = parseFloat(e.target.value)} // Mise à jour de la température cible
        />
        <span>{device.targetTemp}°C</span>
      </div>

      <br />
      {/* Mode d'alimentation */}
      <div className="power-mode">
        <label htmlFor="powerMode" padding-right >Mode d'alimentation</label>
        
        <select 
          id="powerMode" 
          value={mode} 
          onChange={(e) => setMode(e.target.value)} // Changer le mode d'alimentation
        >
          <option value="batterie">Batterie</option>
          <option value="branché">Branché</option>
        </select>
      </div>

      

      

      
    </div>
  );
}

export default SmartDeviceCard;
